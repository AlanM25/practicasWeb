<?php

require "config.php";
require_once APP_PATH . "session.php";

require APP_PATH . "views/archivos_favoritos.view.php";