<?php

require "config.php";
require_once APP_PATH . "session.php";

require APP_PATH . "views/update_user_data.view.php";